/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Foumilayo
 */
public class Services {
     private String libelle;
     
      public Services() {
    }
      
      public Services(String libelle) {
        
    }
       public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }
    @Override
    public String toString() {
        return "services{" + "libellé=" + libelle+  '}';
    }
    
    public Services affecterServiceAEmploye(Services services) {
       
        if(services.getEmploye().getId()==0){
            this.ajouterEmploye(services.getEmploye());
        }
       
           this.setServices(services, services.getServices());
         
        return services;
    }
    
    @Override
    public Services ajouterServices(services) {
        
         return services; 
    }
    }

    private Object getEmploye() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
