/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Foumilayo
 */
public class Employe {
     private String nomComplet;
     private String dateEmbauche;
  
     
      public Employe() {
    }

    

    public Employe(String nomComplet, String dateEmbauche) {
        
        this.nomComplet = nomComplet;
        this.dateEmbauche = dateEmbauche;
        
    }

    

    public String getNomComplet() {
        return nomComplet;
    }

    public void setNomComplet(String nomComplet) {
        this.nomComplet = nomComplet;
    }

    public String getDateEmbauche() {
        return dateEmbauche;
    }

    public void setDateEmbauche(String dateEmbauche) {
        this.dateEmbauche = dateEmbauche;
    }
 @Override
    public String toString() {
        return "Employe{" + "nomComplet=" + nomComplet+ ", dateEmbauche=" + dateEmbauche +  '}';
    }
    
   /* private Object getEmploye() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/

    private void ajouterEmploye(Object employe) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    


    
}
